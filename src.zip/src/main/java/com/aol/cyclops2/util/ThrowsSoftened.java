package com.aol.cyclops2.util;

public @interface ThrowsSoftened {

    Class[]value();
}
