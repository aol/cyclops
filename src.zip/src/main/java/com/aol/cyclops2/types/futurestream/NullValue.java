package com.aol.cyclops2.types.futurestream;

public class NullValue {
    public final static Object NULL = new Object();
}
