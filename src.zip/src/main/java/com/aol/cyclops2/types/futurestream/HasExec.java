package com.aol.cyclops2.types.futurestream;

import java.util.concurrent.Executor;

public interface HasExec {
    Executor getExec();
}
