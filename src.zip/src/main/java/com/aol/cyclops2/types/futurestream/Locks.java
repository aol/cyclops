package com.aol.cyclops2.types.futurestream;

class Locks {

    static Object lock = new Object();
}
