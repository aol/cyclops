package com.aol.cyclops2.types.factory;

import java.util.function.Supplier;

/**
 * A Data type that supports instantiation of instances of the same type 
 * 
 * @author johnmcclean
 *
 * @param <T> Data type of element(s) stored inside this Pure instance
 */
@FunctionalInterface
public interface Unit<T> {

    public <T> Unit<T> unit(T unit);

}
