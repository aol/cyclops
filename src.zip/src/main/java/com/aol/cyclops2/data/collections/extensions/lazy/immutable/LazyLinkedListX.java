package com.aol.cyclops2.data.collections.extensions.lazy.immutable;


import com.aol.cyclops2.data.collections.extensions.api.PStack;
import com.aol.cyclops2.types.foldable.Evaluation;
import cyclops.collectionx.immutable.LinkedListX;
import cyclops.control.Option;
import cyclops.data.Seq;
import cyclops.function.Reducer;
import cyclops.reactive.ReactiveSeq;


import java.util.*;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.Supplier;

/**
 * An extended List type {@see java.util.List}
 * Extended List operations execute lazily e.g.
 * <pre>
 * {@code
 *    StreamX<Integer> q = StreamX.of(1,2,3)
 *                                      .transform(i->i*2);
 * }
 * </pre>
 * The transform operation above is not executed immediately. It will only be executed when (if) the data inside the
 * queue is accessed. This allows lazy operations to be chained and executed more efficiently e.g.
 *
 * <pre>
 * {@code
 *    DequeX<Integer> q = DequeX.of(1,2,3)
 *                              .transform(i->i*2);
 *                              .filter(i->i<5);
 * }
 * </pre>
 *
 * The operation above is more efficient than the equivalent operation with a ListX.
 *
 * @author johnmcclean
 *
 * @param <T> the type of elements held in this toX
 */
public class LazyLinkedListX<T> extends AbstractLazyPersistentCollection<T,PStack<T>> implements LinkedListX<T> {

    private final FoldToList<T> generator;

    public static final <T> Function<ReactiveSeq<PStack<T>>, PStack<T>> asyncLinkedList() {
        return r -> {
            CompletableLinkedListX<T> res = new CompletableLinkedListX<>();
            r.forEachAsync(l -> res.complete(l));
            return res.asLinkedListX();
        };
    }
    public LazyLinkedListX(PStack<T> list, ReactiveSeq<T> seq, Reducer<PStack<T>> reducer, FoldToList<T> generator,Evaluation strict) {
        super(strict,list, seq, reducer,asyncLinkedList());
        this.generator = generator;

        handleStrict();



    }
    public LazyLinkedListX(PStack<T> list, ReactiveSeq<T> seq, Reducer<PStack<T>> reducer,Evaluation strict) {
        super(strict,list, seq, reducer,asyncLinkedList());
        this.generator = new PStackGeneator<>();
        handleStrict();


    }
    public class PStackGeneator<T> implements FoldToList<T> {
         public PStack<T> from(final Iterator<T> i,int depth) {

            if(!i.hasNext())
                return Seq.empty();
            T e = i.next();
            return  from(i,depth++).plus(e);
        }
    }
   
    public PStack<T> materializeList(ReactiveSeq<T> toUse){

        return toUse.visit(s -> {
            PStack<T> res = generator.from(toUse.iterator(),0);
            return new LazyLinkedListX<T>(
                    res,null, this.getCollectorInternal(),generator, evaluation());
                },
                r -> super.materializeList(toUse),
                a -> super.materializeList(toUse));



    }
    

    //@Override
    public LinkedListX<T> materialize() {
        get();
        return this;
    }


    @Override
    public LinkedListX<T> lazy() {
        return new LazyLinkedListX<T>(list,seq.get(),getCollectorInternal(),Evaluation.LAZY) ;
    }

    @Override
    public LinkedListX<T> eager() {
        return new LazyLinkedListX<T>(list,seq.get(),getCollectorInternal(),Evaluation.EAGER) ;
    }

    @Override
    public LinkedListX<T> type(Reducer<? extends PStack<T>> reducer) {
        return new LazyLinkedListX<T>(list,seq.get(),Reducer.narrow(reducer),generator, evaluation());
    }

    //  @Override
    public <X> LazyLinkedListX<X> fromStream(ReactiveSeq<X> stream) {

        Reducer<PStack<T>> reducer = getCollectorInternal();
        return new LazyLinkedListX<X>((PStack<X>)getList(),(ReactiveSeq)stream,(Reducer)reducer,(FoldToList)generator, evaluation());
    }

    @Override
    public <T1> LazyLinkedListX<T1> from(Iterable<T1> c) {
        if(c instanceof PStack)
            return new LazyLinkedListX<T1>((PStack)c,null,(Reducer)getCollectorInternal(),(FoldToList)generator, evaluation());
        return fromStream(ReactiveSeq.fromIterable(c));
    }
    public <T1> LazyLinkedListX<T1> from(PStack<T1> c) {

            return new LazyLinkedListX<T1>(c,null,(Reducer)getCollectorInternal(),(FoldToList)generator, evaluation());

    }


    @Override
    public LinkedListX<T> removeAll(Iterable<? extends T> list) {
        return from(get().removeAll(list));
    }

    @Override
    public LinkedListX<T> removeValue(T remove) {
        return from(get().remove(remove));
    }

    @Override
    public LinkedListX<T> updateAt(int i, T e) {
        return from(get().updateAt(i,e));
    }

    @Override
    public LinkedListX<T> insertAt(int i, T e) {
        return from(get().insertAt(i,e));
    }

    @Override
    public LinkedListX<T> plus(T e) {
        return from(get().plus(e));
    }

    @Override
    public LinkedListX<T> plusAll(Iterable<? extends T> list) {
        return from(get().plusAll(list));
    }

    @Override
    public LinkedListX<T> insertAt(int i, Iterable<? extends T> list) {
        return from(get().insertAt(i,list));
    }

    @Override
    public LinkedListX<T> removeAt(int i) {
        return from(get().minusAt(i));
    }

    @Override
    public LinkedListX<T> subList(int start, int end) {
        return from(get().subList(start,end));
    }
/**
    @Override
    public boolean addAll(int index, Collection<? extends T> c) {
        return getValue().addAll(index,c);
    }

    @Override
    public T getValue(int index) {
        return getValue().getValue(index);
    }

    @Override
    public T set(int index, T element) {
        return getValue().set(index,element);
    }

    @Override
    public void add(int index, T element) {
         getValue().add(index,element);
    }

    @Override
    public T removeValue(int index) {
        return getValue().removeValue(index);
    }

    @Override
    public int indexOf(Object o) {
        return getValue().indexOf(o);
    }

    @Override
    public int lastIndexOf(Object o) {
        return getValue().lastIndexOf(o);
    }

    @Override
    public ListIterator<T> listIterator() {
        return getValue().listIterator();
    }

    @Override
    public ListIterator<T> listIterator(int index) {
        return getValue().listIterator(index);
    }

**/
    public PStack<T> subList(int start) {
        return get().subList(start);
    }

    @Override
    public <U> LazyLinkedListX<U> unitIterator(Iterator<U> it) {
        return fromStream(ReactiveSeq.fromIterator(it));
    }



    @Override
    public <R> LazyLinkedListX<R> unit(Iterable<R> col) {
        return from(col);
    }

    @Override
    public LinkedListX<T> plusLoop(int max, IntFunction<T> value) {
        return (LinkedListX<T>)super.plusLoop(max,value);
    }

    @Override
    public LinkedListX<T> plusLoop(Supplier<Option<T>> supplier) {
        return (LinkedListX<T>)super.plusLoop(supplier);
    }

    @Override
    public Option<T> get(int index) {
        PStack<T> x = get();
        return x.get(index);
    }

    @Override
    public T getOrElse(int index, T value) {
        PStack<T> x = get();
        if(index>x.size())
            return value;
        return x.getOrElse(index,value);
    }

    @Override
    public T getOrElseGet(int index, Supplier<? extends T> supplier) {
        PStack<T> x = get();
        if(index>x.size())
            return supplier.get();
        return x.getOrElseGet(index,supplier);
    }
}
