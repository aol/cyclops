package com.aol.cyclops2.data.collections.extensions.api;

import cyclops.reactive.ReactiveSeq;

import java.util.Collection;

 public interface PCollection<T> extends Iterable<T>{//{, Collection<T> {

     PCollection<T> plus(T e);

     PCollection<T> plusAll(Iterable<? extends T> list);


     PCollection<T> remove(T e);

     int size();

     PCollection<T> removeAll(Iterable<? extends T> list);

     default boolean isEmpty(){
         return size()==0;
     }

     boolean contains(T item);

     default ReactiveSeq<T> stream(){
         return ReactiveSeq.fromIterable(this);
     }

/**
    @Deprecated boolean add(T o);
    @Deprecated boolean removeValue(Object o);
    @Deprecated boolean addAll(Collection<? extends T> c);
    @Deprecated boolean removeAll(Collection<?> c);
    @Deprecated boolean retainAll(Collection<?> c);
    @Deprecated void clear();
    **/
}
