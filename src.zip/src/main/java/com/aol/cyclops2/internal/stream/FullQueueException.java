package com.aol.cyclops2.internal.stream;

/**
 * Created by johnmcclean on 16/05/2017.
 */
public class FullQueueException extends Throwable {
}
