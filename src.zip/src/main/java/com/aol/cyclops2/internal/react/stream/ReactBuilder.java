package com.aol.cyclops2.internal.react.stream;

public interface ReactBuilder {

}
