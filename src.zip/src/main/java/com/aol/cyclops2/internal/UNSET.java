package com.aol.cyclops2.internal;

public class UNSET {
    public static Object VOID = new Object();
}
