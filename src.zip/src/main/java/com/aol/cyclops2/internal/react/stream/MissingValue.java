package com.aol.cyclops2.internal.react.stream;

public class MissingValue {
    public final static MissingValue MISSING_VALUE = new MissingValue();

}
