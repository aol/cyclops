package cyclops.data;


public interface DataWitness {

    public static enum lazySeq{}
    public static enum nonEmptyList{}
    public static enum seq{}
    public static enum lazyString{}
    public static enum zipper{}
    public static enum hlist{}
    public static enum differenceList{}

    public static enum tree{}

    public static enum bankersQueue{}

    public static enum immutableVector{}
    public static enum intMap{}

    public static enum immutableHashSet{}
    public static enum orderedSet{}

    public static enum immutableTreeMap{}
    public static enum trieMap{}
    public static enum immutableHashMap{}
    public static enum immutableLinkedHashMap{}
    public static enum multiMap{}
    public static enum multiMapHK{}



}
