package cyclops.function.checked;

public interface CheckedDoublePredicate {
    public boolean test(double test) throws Throwable;
}
