package cyclops.function.checked;

public interface CheckedDoubleConsumer {
    public void accept(double a) throws Throwable;
}
