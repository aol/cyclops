package cyclops.function.checked;

public interface CheckedIntSupplier {
    public int getAsInt() throws Throwable;
}
