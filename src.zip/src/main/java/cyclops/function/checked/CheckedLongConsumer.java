package cyclops.function.checked;

public interface CheckedLongConsumer {
    public void accept(long a) throws Throwable;
}
