package cyclops.function.checked;

public interface CheckedIntPredicate {
    public boolean test(int test) throws Throwable;
}
