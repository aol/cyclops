package cyclops.function.checked;

public interface CheckedIntConsumer {
    public void accept(int a) throws Throwable;
}
