package cyclops.function.checked;

public interface CheckedDoubleSupplier {
    public double getAsDouble() throws Throwable;
}
